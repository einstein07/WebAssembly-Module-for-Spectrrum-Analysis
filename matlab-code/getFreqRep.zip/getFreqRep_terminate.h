/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getFreqRep_terminate.h
 *
 * Code generation for function 'getFreqRep_terminate'
 *
 */

#ifndef GETFREQREP_TERMINATE_H
#define GETFREQREP_TERMINATE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void getFreqRep_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (getFreqRep_terminate.h) */
