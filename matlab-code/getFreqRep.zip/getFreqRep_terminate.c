/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getFreqRep_terminate.c
 *
 * Code generation for function 'getFreqRep_terminate'
 *
 */

/* Include files */
#include "getFreqRep_terminate.h"
#include "getFreqRep_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void getFreqRep_terminate(void)
{
  /* (no terminate code required) */
  isInitialized_getFreqRep = false;
}

/* End of code generation (getFreqRep_terminate.c) */
