/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getFreqRep_data.h
 *
 * Code generation for function 'getFreqRep_data'
 *
 */

#ifndef GETFREQREP_DATA_H
#define GETFREQREP_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern boolean_T isInitialized_getFreqRep;

#endif
/* End of code generation (getFreqRep_data.h) */
