/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getFreqRep_data.c
 *
 * Code generation for function 'getFreqRep_data'
 *
 */

/* Include files */
#include "getFreqRep_data.h"

/* End of code generation (getFreqRep_data.c) */
