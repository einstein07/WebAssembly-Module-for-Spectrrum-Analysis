/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * getFreqRep_data.c
 *
 * Code generation for function 'getFreqRep_data'
 *
 */

/* Include files */
#include "getFreqRep_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_getFreqRep = false;

/* End of code generation (getFreqRep_data.c) */
